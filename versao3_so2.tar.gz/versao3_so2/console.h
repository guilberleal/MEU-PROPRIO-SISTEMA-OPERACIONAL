//#define CLEAR_SCREEN ""
#define CURSOR_TOP_LEFT "\x1B[1;1H"
#define BS "\b \b"
#define CLEAR_SCREEN "\x1B[0J"