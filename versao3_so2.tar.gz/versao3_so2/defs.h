void uartinit();
int uartgetc();
void uartputc(char c);