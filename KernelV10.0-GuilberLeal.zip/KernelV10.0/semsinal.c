#include <stdio.h>
int main(){
    int i=200;
    char j= 130;
    printf("%d+%d = %d\n",i,j,i+j);
    return 0;
}