#include "types.h"
//UART
void uartinit();
int uartgetc();
void uartputc(char c);
//Printf
void printf(char *,...);
//Memory
void memory_init();
void* kalloc(int);