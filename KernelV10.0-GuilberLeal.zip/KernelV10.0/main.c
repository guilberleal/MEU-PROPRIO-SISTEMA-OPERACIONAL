#define uart_base 0x10000000
#include "defs.h"
#include "console.h"
#include "riscv.h"
#include "types.h"

extern void mvector(void);
extern void msg_syscall(int);
extern void sethostname(char*, int);
extern void halt(void);
extern void time(void);

void printlng(long, int);
int perimetro(int ,...);
void testa_variadics();

void puts(char *s){
   while(*s!=0){ 
    uartputc(*s++);
    }
}

void main(){
    uartinit();
    //puts(CURSOR_TOP_LEFT);
    //puts(CLEAR_SCREEN);
    //puts(COLOR_BACKGROUND);
    //puts(COLOR_FOREGROUND);
    
    printf("-- Roncador Operating System --\n");
    r_mstatus();

    int c;
    //configuracao inicial do dispositivo uart
    
    for(;;){
        c=uartgetc();
        if(c==-1)
            continue;
        switch (c)
        {
            case '\r':
                uartputc('\r');
                uartputc('\n');
            case 127://del
                //uartputc('\b');
                //uartputc(' ');
                //uartputc('\b');
                puts(BS);
                break;
            case '\x1B':
                puts(CURSOR_TOP_LEFT);
            case 'S':
                msg_syscall(8);
                break;

            case 'H':
                sethostname("UFMT",4);
                break;
            case 'C':
                halt();
                break;

            case 'T':
                time();
                break;
            default:
                uartputc(c);

         }
    }

}
void testa_variadics(){
    //int p;
    //p = perimetro(3,3,4,5);
    puts("Perimetro de triangulo com lados 8: ");
    printlng(perimetro(4,8,8,8,8),10);

    
}
void entry(){
    memory_init();//inicializa memoria

    //rotina para salvar o contexto
    uint64 x = (uint64) mvector;
    w_mtvec(x);

    /*
    alterar registartador mstatus para permitir mudanca de modo
    Objetivo: mudar para modo-S (Supervisor)
    */
    x = r_mstatus();
    
    x = x & ~(3L << 11); // zera os bits 12 e 11
    x = x | (1L<<11); // seta os bits 12 e 11 para 01
    w_mstatus(x);

    //muda pro modo-S
    w_mepc((uint64)main); //envia para mepc o endereco de main 
    asm volatile("mret");
}

void panic(char *msg){
    printf("\U0001F480 SO em panico. Causa: %s\n",msg);
    for(;;);
}
