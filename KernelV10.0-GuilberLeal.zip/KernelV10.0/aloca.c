#include <stdio.h>

int main(int argc, char*argv[]){
    int grande[1000][1000][1000]; //alocando 4GB
    return 0;
}