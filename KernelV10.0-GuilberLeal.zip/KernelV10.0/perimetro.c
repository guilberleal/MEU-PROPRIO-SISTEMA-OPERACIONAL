#include <stdarg.h>

int perimetro(int lados, ...){
    va_list ap; //ponteiro para a lista de argumentos, ap aponta para o primeiro elemento da lista.

    int i  = 0;
    int soma = 0;

    va_start(ap,lados); //inicializa ponteiros
    
    for(i = 0; i < lados; i++){
        soma += va_arg(ap, int); //obtem o lado e adciona na soma
    }
    return soma;
}