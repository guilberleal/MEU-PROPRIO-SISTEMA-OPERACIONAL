#include "types.h"
#include "proc.h"
#include "defs.h"
#include "memlayout.h"

extern void panic(char *msg);

//tratamentos de excecoes
void mtrap(uint64 tval,uint64 cause,TrapFrame *tf){
    uint64 *mtime  = (uint64 *) CLINT_MTIME;
    if((long) cause > 0){
        //excecao sincrona
        switch (cause)
        {
        case 2: //instrucao ilegal
            printf("\n<Trap> Instrucao ilegal [CPU#:%d] epc:%p tval:%p\n",tf->hartid,(uint64 *)tf->epc,(uint64 *)tval);
            tf->epc = tf->epc + 4; //Instrucao seguinte a que causou a excecao
            break;
        case 9: //chamada de sistema
            if(tf->a7 == 1){ //identificador da syscall
                //msg_syscall()
                printf("\n<Trap> Chamada de sistema msg_syscall [id:%d, arg1:%d]\n", tf->a7,tf->a0);
                
            }
            else if(tf->a7 == 2){
                printf("\n<Trap> Chamada de sistema sethostname[id:%d]", tf->a7);
                printf("\nO nome do Host agora eh: %s, e o tamanho da palavra eh: %d\n",tf->a0,tf->a1);
                
            }
            else if(tf->a7 == 3){
                printf("\n<Trap> Chamada de sistema Halt");
                printf("\nseu sistema Operacional foi congelado\n");
                panic("GAME OVER");
             
            }
            else if(tf->a7 == 4){

                int segundos, m, s, resto;
                segundos = *mtime / 10000000;

            
                resto = segundos % 3600;
                m = resto / 60;
                s = resto % 60;
                printf("\nO tempo de execucao eh:%d Minutos : %d Segundos\n", m, s);


                
               
             
                
            }
            tf->epc = tf->epc + 4; //o rw retorna para a instrucao seguinte que causou a excecao
            break;

        default:
            break;
        }
    }
    else{
        //interrupcao

    }
}